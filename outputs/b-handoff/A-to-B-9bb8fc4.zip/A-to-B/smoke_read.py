import hashlib, json
from pathlib import Path
from interfaces.a_contract import validate_a
root = Path(__file__).resolve().parent
manifest = json.loads((root/'MANIFEST.json').read_text(encoding='utf-8'))
for name, sha in manifest['files_sha256'].items():
    assert hashlib.sha256((root/name).read_bytes()).hexdigest() == sha, name
a = validate_a(json.loads((root/'outputs/a/handoff/analysis.example.json').read_text(encoding='utf-8')))
mapping = {'before_source': 'examples/teaching/int-threshold/before/Threshold.java',
           'patch_source': 'examples/teaching/int-threshold/patch/Threshold.java',
           'diff_path': 'examples/teaching/int-threshold/patch.diff'}
for role, name in mapping.items():
    assert hashlib.sha256((root/name).read_bytes()).hexdigest() == a['sources'][role]['sha256'], role
for c in a['candidates']:
    print(c['candidate_id'], c['method']['signature'], c['arguments'])
print('PASS: package integrity + A consumer checks + mapped source hashes; no Java execution/oracle')
